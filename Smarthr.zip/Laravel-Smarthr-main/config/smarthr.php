<?php
return [
    'template' => 'default',
    'layout' => 'vertical',
    'topbar' => 'light',
    'sidebar' => 'dark',
    'sidebar-size' => 'lg',
    'data-sidebar-image' => 'none',
];
