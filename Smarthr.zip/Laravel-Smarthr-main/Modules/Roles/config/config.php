<?php

return [
    'name' => 'Roles',
];
