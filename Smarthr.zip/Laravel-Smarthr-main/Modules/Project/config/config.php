<?php

return [
    'name' => 'Project',
];
