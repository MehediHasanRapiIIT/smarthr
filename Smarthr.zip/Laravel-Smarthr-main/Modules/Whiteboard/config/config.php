<?php

return [
    'name' => 'Whiteboard',
];
