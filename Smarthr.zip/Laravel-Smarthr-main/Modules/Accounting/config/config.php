<?php

return [
    'name' => 'Accounting',
];
