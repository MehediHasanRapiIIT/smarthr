<?php
namespace App\Http\Controllers;

class BaseController extends Controller {

    public $data;

    public function __construct()
    {
       $this->data;
    }

}
