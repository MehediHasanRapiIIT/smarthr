<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\LaravelBackupPanelServiceProvider::class,
    App\Providers\MacrosServiceProvider::class,
];
