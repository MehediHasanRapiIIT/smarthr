<?php

declare(strict_types=1);

return [
    'next'     => 'Sljedeća &raquo;',
    'previous' => '&laquo; Prethodna',
];
